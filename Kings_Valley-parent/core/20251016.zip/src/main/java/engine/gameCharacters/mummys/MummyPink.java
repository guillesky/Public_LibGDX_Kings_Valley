package engine.gameCharacters.mummys;

import engine.gameCharacters.player.Player;
import engine.level.Pyramid;
import util.GameRules;

/**
 * Representa una momia rosa
 * 
 * @author Guillermo Lazzurri
 */
@SuppressWarnings("serial")
public class MummyPink extends Mummy
{

	/**
	 * 
	 * 
	 * Llama a super(MummyFactory.PINK_MUMMY, x,
	 * y,Config.getInstance().getMummyPinkParameters(), pyramid,player);
	 * 
	 * 
	 * @param x       Coordenada x
	 * @param y       Coordenada y
	 * @param pyramid piramide en la que esta ubicada la momia
	 * @param player  referencia al player que la momia persigue
	 * 
	 */

	public MummyPink(float x, float y, Pyramid pyramid, Player player)
	{
		super(MummyFactory.PINK_MUMMY, x, y, GameRules.getInstance().getMummyPinkParameters(), pyramid, player);

	}

	/**
	 * Retorna una cadena de texto que representa la momia (solo para debug)
	 */
	@Override
	public String toString()
	{
		return "MummyPink " + super.toString();
	}

}
