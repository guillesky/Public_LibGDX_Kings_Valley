package engine.gameCharacters.mummys;

import java.util.ArrayList;
import java.util.Iterator;

import com.badlogic.gdx.math.Vector2;

import engine.KVEventListener;
import engine.game.Game;
import engine.gameCharacters.abstractGameCharacter.GameCharacter;
import engine.level.LevelObject;
import engine.level.Pyramid;
import engine.level.Stair;
import util.GameRules;

/**
 * Clase que representa del estado de la momia "Decidiendo"
 * 
 * @author Guillermo Lazzurri
 */
public class MummyStateDeciding extends MummyState
{

	/**
	 * Constructor de clase, llama a super(mummy, Mummy.ST_IDDLE);
	 * 
	 * @param mummy Correspondiente al sujeto del patron state
	 */
	public MummyStateDeciding(Mummy mummy)
	{
		super(mummy, Mummy.ST_IDDLE);
		this.timeToChange = this.mummy.getTimeDeciding();

		this.update(0);

	}

	/**
	 * Si pasa el tiempo corresponediente a this.timeToChange entonces llama a
	 * this.changeStatus();
	 */
	@Override
	public void update(float deltaTime)
	{
		if (this.mummy.getTimeInState() >= this.timeToChange && (this.mummy.getState()==GameCharacter.ST_WALKING ||this.mummy.getState()==GameCharacter.ST_IDDLE))
		{
			this.changeStatus();
		}
		this.mummy.move(new Vector2(), false, deltaTime);

	}

	/**
	 * De acuerdo a la posicion del player puede pasar a los estados
	 * MummyStateSearchingStair o MummyStateWalking
	 */
	private void changeStatus()
	{
		if (this.mummy.player.y > this.mummy.y)// player esta arriba
		{
			NearStairResult nearStairResult = this.getNearStair(true);

			if (nearStairResult != null)
			{
				this.mummy.mummyState = new MummyStateSearchingStair(this.mummy, nearStairResult,
						MummyState.PLAYER_IS_UP);
			} else
			{
				int directionX = this.searchEndPlatform(EndPlatformOLD.END_STEP);
				if (directionX == NONE)
					directionX = this.searchEndPlatform(EndPlatformOLD.END_CLIFF);
				this.mummy.mummyState = new MummyStateWalking(this.mummy, directionX, MummyState.PLAYER_IS_UP);
			}

		} else if (this.mummy.player.y < this.mummy.y)// player esta abajo
		{
			NearStairResult nearStairResult = this.getNearStair(false);
			if (nearStairResult != null)
			{
				this.mummy.mummyState = new MummyStateSearchingStair(this.mummy, nearStairResult,
						MummyState.PLAYER_IS_DOWN);

			} else
			{
				int direccion = this.searchEndPlatform(EndPlatformOLD.END_CLIFF);
				if (direccion == NONE)
					direccion = this.searchEndPlatform(EndPlatformOLD.END_STEP);
				this.mummy.mummyState = new MummyStateWalking(this.mummy, direccion, MummyState.PLAYER_IS_DOWN);
			}

		} else
		{
			this.mummy.mummyState = new MummyStateWalking(this.mummy, MummyState.NONE, MummyState.PLAYER_IS_SOME_LEVEL);

		} // player esta al mismo nivel

	}

	/**
	 * Retorna true
	 */
	@Override
	protected boolean isDanger()
	{
		return true;
	}

	/**
	 * Llamado internamente por changeStatus. Indica hacia donde debe ir la momia
	 * dependiendo del tipo de fin de plataforma.
	 * 
	 * @param typeEnd indica el tipo de fin de plataforma, tomara los valores:
	 *                EndPlatform.END_CLIFF o EndPlatform.END_STEP
	 * @return valor numerico que tomara los valores NONE, LEFT o RIGHT
	 */
	private int searchEndPlatform(int typeEnd)
	{
		int r = NONE;
		EndPlatformOLD endToRight = this.endPlatform(true);
		EndPlatformOLD endToLeft = this.endPlatform(false);
		if (endToRight.getType() == typeEnd || endToLeft.getType() == typeEnd)
		{
			if (endToRight.getType() != typeEnd)
				r = LEFT;
			else if (endToLeft.getType() != typeEnd)
				r = RIGHT;
			else
			{

				if (this.mummy.x < this.mummy.player.x)

					r = RIGHT;
				else
					r = LEFT;
			}
		}

		return r;
	}

	/**
	 * Llamado cuando la momia muere. Cambia el estado a new
	 * MummyStateDying(this.mummy, mustTeleport); Ademas dispara el evento:
	 * Game.getInstance().eventFired(KVEventListener.MUMMY_DIE, this);
	 */
	@Override
	protected void die(boolean mustTeleport)
	{
		this.mummy.mummyState = new MummyStateDying(this.mummy, mustTeleport);
		Game.getInstance().eventFired(KVEventListener.MUMMY_DIE, this);
	}

	
	/**
	 * Retorna el resultado de buscar una escalera cercana que suba o baje (podria
	 * retornar true)
	 * 
	 * @param toUp true si se busca una escalera que suba, false si busco una
	 *             escalera que baje
	 * @return El resultado de la escalera buscada, si no hay una escalera con las
	 *         caracteristicas pedidas, retorna null
	 */
	protected NearStairResult getNearStair(boolean toUp)
	{
		Stair stair = null;
		Stair toRight = this.nearStair(toUp, true);
		Stair toLeft = this.nearStair(toUp, false);

		if (toRight == null)
			stair = toLeft;
		else
		{
			if (toLeft == null)
				stair = toRight;
			else
			{

				LevelObject footStairRight;
				LevelObject footStairLeft;

				if (toUp)
				{
					footStairRight = toRight.getDownStair();
					footStairLeft = toLeft.getDownStair();
				} else
				{
					footStairRight = toRight.getUpStair();
					footStairLeft = toLeft.getUpStair();
				}

				if (footStairRight.x - mummy.x < mummy.x - footStairLeft.x)
					stair = toRight;
				else
					stair = toLeft;

			}
		}
		NearStairResult r = null;
		if (stair != null)
		{
			if (stair == toRight)
				r = new NearStairResult(stair, RIGHT);
			else
				r = new NearStairResult(stair, LEFT);
		}
		return r;
	}
	/**
	 * Metodo que retorna la escalera mas cercana a la momia hacia las direcciones
	 * indicadas. Si no hay una escalera en la direccion pretendida retorna null
	 * 
	 * @param toUp    true si se pretende subir, false si se pretende bajar
	 * @param toRight true si busco hacia la derecha, false si busco a la izquierda
	 * @return La escalera mas cercana a la direccion pretendida. Si no hay escalera
	 *         en la plataforma en la direccion requerido retorna null
	 */
	private Stair nearStair(boolean toUp, boolean toRight)
	{
		Stair r = null;
		Pyramid pyramid = mummy.getPyramid();
		int count = this.endPlatform(toRight).getCount();
		ArrayList<Stair> candidatesStairs = new ArrayList<Stair>();
		LevelObject footStair;

		Iterator<Stair> it = pyramid.getAllStairs().iterator();
		float tileWidth = GameRules.getInstance().getLevelTileWidthUnits();
		float posX = mummy.x + mummy.width * 0.5f;
		while (it.hasNext())
		{
			Stair stair = it.next();
			if (toUp)
				footStair = stair.getDownStair();
			else
				footStair = stair.getUpStair();
			if (footStair.y == mummy.y && (toRight && footStair.x >= posX || !toRight && footStair.x <= posX))
				candidatesStairs.add(stair);
		}

		if (!candidatesStairs.isEmpty())
		{
			it = candidatesStairs.iterator();
			Stair stair = it.next();
			if (toUp)
				footStair = stair.getDownStair();
			else
				footStair = stair.getUpStair();

			Stair minStair = stair;

			float aux = posX - (footStair.x + footStair.width * 0.5f);
			if (aux < 0)
				aux *= -1;
			int min = (int) (aux / (float) tileWidth);
			while (it.hasNext())
			{
				stair = it.next();
				if (toUp)
					footStair = stair.getDownStair();
				else
					footStair = stair.getUpStair();

				aux = posX - (footStair.x + footStair.width * 0.5f);
				if (aux < 0)
					aux *= -1;
				int dist = (int) (aux / (float) tileWidth);
				if (dist < min)
				{
					min = dist;

					minStair = stair;
				}
			}
			if (min <= count)
				r = minStair;
		}

		return r;
	}
	/**
	 * Crea y retorna un objeto de tipo EndPlatform indicando el tipo de final de
	 * plataforma buscado
	 * 
	 * @param toRight true si se busca el final de plataforma or derecha, false si
	 *                se lo busca por izquierda
	 * @return Objeto de tipo EndPlatform que indica el tipo de final de plataforma
	 */
	protected EndPlatformOLD endPlatform(boolean toRight)
	{
		int inc;
		int acum = 0;
		int type;
		int count;
		float x;
		Pyramid pyramid = mummy.getPyramid();
		x = mummy.x;
		if (toRight)
		{
			inc = 1;
			x += mummy.width;
		} else

		{
			inc = -1;

		}

		while (pyramid.getCell(x, mummy.y, acum, 0) == null && pyramid.getCell(x, mummy.y, acum, 1) == null
				&& pyramid.getCell(x, mummy.y, acum, -1) != null && this.isColDesplaInMap(acum))
		{
			acum += inc;

		}
		type = this.typeEndPlatform(x, acum);
		if (acum < 0)
			acum *= -1;
		count = acum;
		EndPlatformOLD r = new EndPlatformOLD(type, count);
		this.correctGiratoryEndPlatform(r, toRight);

		return r;

	}

	/**
	 * Corrige los atributos del objeto endPlatform pasado como parametro en caso de
	 * encontrar una puerta giratoria. En ese caso se considera que hay un bloqueo
	 * insalvable para la momia. Este metodo es invocado por this.endPlatform
	 * 
	 * @param endPlatform objeto de tipo endPlatform que debe ser evaluado. Su
	 *                    estado podria cambiar
	 * @param toRight     true si el endPlatform esta a la derecha, false si esta a
	 *                    la izquierda.
	 */
	private void correctGiratoryEndPlatform(EndPlatformOLD endPlatform, boolean toRight)
	{
		Iterator<LevelObject> it = mummy.getPyramid().getGiratories().iterator();
		boolean condicion = false;
		float posX = mummy.x;

		if (toRight)
			posX += mummy.width;

		while (it.hasNext() && !condicion)
		{
			LevelObject giratoria = it.next();
			if (giratoria.y == mummy.y && (toRight && giratoria.x >= posX || !toRight && giratoria.x <= posX))
			{
				float aux = posX - (giratoria.x + giratoria.width * 0.5f);
				if (aux < 0)
					aux *= -1;
				int dist = (int) (aux / (float) GameRules.getInstance().getLevelTileWidthUnits());

				if (dist < endPlatform.getCount())
				{
					endPlatform.setCount(dist);
					endPlatform.setType(EndPlatformOLD.END_BLOCK);
					condicion = true;
				}
			}
		}

	}

	/**
	 * Metodo llamado internadmente por this.endPlatform. Evita que durante los
	 * calculos se busque fuera de la piramide
	 * 
	 * @param col cantidad de desplazamiento
	 * @return true si se esta dentro del mapa, false en caso contrario.
	 */
	private boolean isColDesplaInMap(int col)
	{

		return mummy.getColPosition() + col > 1
				&& mummy.getColPosition() + col < mummy.getPyramid().getMapWidthInTiles() - 1;
	}

}
