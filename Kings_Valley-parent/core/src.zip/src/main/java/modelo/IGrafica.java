package modelo;

public interface IGrafica 
{

    void addGraphicElement(Object element);
    void removeGraphicElement(Object element);
    

}
