package io.github.some_example_name;

import com.badlogic.gdx.ApplicationListener;

import modelo.IGrafica;

public interface IMyApplicationListener extends IGrafica, ApplicationListener
{

}
