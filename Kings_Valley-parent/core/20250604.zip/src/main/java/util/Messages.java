package util;

public enum Messages
{

    GAME_PAUSED("Juego Pausado"),CURRENT_PYRAMID("Piramide Actual: "), SCORE("Score: "), LIVES("Lives: ");

    private String value;

    private Messages(String value)
    	{
    		this.value = value;
    	}

    public String getValue()
    {
	return value;
    }

    public void setValue(String valor)
    {
	this.value = valor;
    }

}
