package modelo.gameCharacters;

import com.badlogic.gdx.math.Vector2;

import modelo.level.Stair;

public class GameCharacterStateOnStair extends GameCharacterState
{
private Stair stair;
    public GameCharacterStateOnStair(GameCharacter gameCharacter,Stair stair)
    {
	super(gameCharacter, GameCharacter.ST_JUMPING);
	this.stair=stair;
    }

    @Override
    protected void move(Vector2 v, boolean b, float deltaTime)
    {
	// TODO Auto-generated method stub

    }

}
