package modelo.gameCharacters;

import com.badlogic.gdx.math.Vector2;

public abstract class GameCharacterState
{
    protected GameCharacter gameCharacter;
    private  int state;
    

    public GameCharacterState(GameCharacter gameCharacter, int state)
    {
	this.gameCharacter = gameCharacter;
	this.state = state;
    }


    protected abstract void move(Vector2 v, boolean b, float deltaTime);
}
