package modelo.gameCharacters;

import java.util.ArrayList;
import java.util.Iterator;

import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import modelo.level.GiratoryMechanism;
import modelo.level.LevelObject;
import modelo.level.Pyramid;
import modelo.level.Stair;
import util.Config;
import util.Constantes;

@SuppressWarnings("serial")
public abstract class GameCharacter extends LevelObject
{

    public static final int ST_IDDLE = 0; // Inicializando
    public static final int ST_WALKING = 11; // Andando
    public static final int ST_ONSTAIRS_POSITIVE = 2; // En una escalera pendiente positiva
    public static final int ST_ONSTAIRS_NEGATIVE = 3; // En una escalera pendiente negativa

    public static final int ST_JUMPING = 5; // Saltando

    public static final int ST_FALLING = 7; // Cayendo

    public static final int ST_DYING = 8; // Muriendo

    protected int state = GameCharacter.ST_IDDLE;

    protected Vector2 motionVector = new Vector2();
    protected float speedFall;
    protected float speedWalk;
    protected float speedWalkStairs;
    protected float speedJump;
    protected int stairInit = Constantes.It_none;
    protected float speedY = 0;
    protected Pyramid pyramid;
    protected boolean lookRight = true;
    protected float animationDelta = 0;
    private Rectangle feet;
    private Stair stair = null;
    protected GameCharacterState gameCharacterState;

    public GameCharacter(int type, float x, float y, float speedWalk, float speedWalkStairs, Pyramid pyramid)
    {
	super(type, x, y, 0, Config.getInstance().getCharacterWidth(), Config.getInstance().getCharacterHeight());
	float feetWidth;
	float feetHeight;

	this.speedFall = Config.getInstance().getCharacterSpeedFall();
	this.speedWalk = speedWalk;
	this.speedWalkStairs = speedWalkStairs;
	this.speedJump = Config.getInstance().getCharacterSpeedJump();

	feetHeight = Config.getInstance().getCharacterFeetHeight();
	feetWidth = Config.getInstance().getCharacterFeetWidth();
	this.pyramid = pyramid;

	float mitad = this.x + this.width / 2;
	mitad -= feetWidth / 2;
	this.feet = new Rectangle(mitad, y, feetWidth, feetHeight);

    }

    protected void move(Vector2 v, boolean b, float deltaTime)
    {

	deltaTime *= Config.getInstance().getSpeedGame();
	if (this.state != GameCharacter.ST_ONSTAIRS_POSITIVE && this.state != GameCharacter.ST_ONSTAIRS_NEGATIVE)
	// Si no estoy en escalera
	{
	    if (!this.isFloorDown()) // aplico gravedad
	    {

		if (this.state == GameCharacter.ST_WALKING || this.state == GameCharacter.ST_IDDLE)
		{

		    this.state = GameCharacter.ST_FALLING;
		    this.motionVector.x = 0;

		    this.animationDelta = 0;
		} // else this.animationDelta += deltaTime;

		this.motionVector.y += this.speedFall * deltaTime;

		if (this.motionVector.y < this.speedFall)
		    this.motionVector.y = speedFall;

	    }

	    else // estoy caminando
	    {

		if (v.x == 0)
		{
		    if (this.state != ST_IDDLE)
		    {
			this.animationDelta = 0;
			this.state = ST_IDDLE;
		    } // else this.animationDelta += deltaTime;

		} else
		{
		    this.lookRight = v.x > 0;
		    if (this.state != ST_WALKING)
		    {
			this.animationDelta = 0;
			this.state = ST_WALKING;

		    } // else this.animationDelta += deltaTime;

		}
		this.motionVector.x = v.x * this.speedWalk;

		// this.motionVector.y = 0;
		if (b)
		    this.doAction();
		if (v.y != 0 && v.x != 0)
		    this.checkEnterStair(v);

	    }
	} else // estoy en escalera
	{
	    this.motionVector.x = v.x * this.speedWalkStairs;
	    if (this.state == GameCharacter.ST_ONSTAIRS_POSITIVE)
	    {
		this.motionVector.y = v.x * this.speedWalkStairs;

	    } else
	    {
		this.motionVector.y = -v.x * this.speedWalkStairs;
	    }
	    if (v.x != 0)
	    {
		this.checkExitStair(v);
		// this.animationDelta += deltaTime;
		this.lookRight = v.x > 0;
	    }
	}

	Vector2 escalado = this.motionVector.cpy().scl(deltaTime);
	if (this.state != GameCharacter.ST_ONSTAIRS_POSITIVE && this.state != GameCharacter.ST_ONSTAIRS_NEGATIVE) // Si
	    // no
	    // estoy
	    // en
	    this.colision(escalado);

	this.x += escalado.x;
	this.y += escalado.y;
	this.checkOutLevel();
    }

    private void checkExitStair(Vector2 v)
    {
	
	LevelObject endStair;
	if (this.stair.isPositive())
	{
	    if (v.x > 0)
	    {
		endStair=this.stair.getUpStair();
		
	    } else
	    {
		endStair=this.stair.getDownStair();
	    }
	} else
	{
	    if (v.x > 0)
	    {
		endStair=this.stair.getDownStair();
	    } else
	    {
		endStair=this.stair.getUpStair();
	    }

	}
	if (this.isFeetColision(endStair))
	{
	    this.state = GameCharacter.ST_WALKING;
	    this.lookRight = v.x > 0;
	    this.animationDelta = 0;
	    this.y = endStair.y;
	    this.motionVector.y = 0;
	}

    }

    protected void checkEnterStair(Vector2 v)
    {
	Stair escalera = null;
	if (v.y > 0)
	{
	    if (v.x > 0)
	    {
		escalera = this.checkStairsFeetColision(this.pyramid.getPositiveStairs(), true);
		if (escalera != null)
		    this.state = GameCharacter.ST_ONSTAIRS_POSITIVE;
	    } else
	    {
		escalera = this.checkStairsFeetColision(this.pyramid.getNegativeStairs(), true);
		if (escalera != null)
		    this.state = GameCharacter.ST_ONSTAIRS_NEGATIVE;
	    }
	} else
	{
	    if (v.x > 0)
	    {
		escalera = this.checkStairsFeetColision(this.pyramid.getNegativeStairs(), false);
		if (escalera != null)
		    this.state = GameCharacter.ST_ONSTAIRS_NEGATIVE;
	    } else
	    {
		escalera = this.checkStairsFeetColision(this.pyramid.getPositiveStairs(), false);
		if (escalera != null)
		    this.state = GameCharacter.ST_ONSTAIRS_POSITIVE;
	    }
	}
	if (escalera != null)
	    this.stair = escalera;
    }

    protected abstract void doAction();

    protected void doJump()
    {
	this.motionVector.y = this.speedJump;
	this.state = GameCharacter.ST_JUMPING;
	this.animationDelta = 0;
    }

    public int getState()
    {
	return state;
    }

    public boolean isFloorDown()
    {
	float epsilon = 0.000001f * Config.getInstance().getLevelTileHeightUnits();
	return ((isCellBlocked(this.x + this.getWidth(), this.y - epsilon * this.height)
		&& isCellBlocked(this.x + this.getWidth(), this.y - this.height * 0.25f))
		|| (isCellBlocked(this.x, this.y - 0.00001f * this.height)
			&& isCellBlocked(this.x, this.y - this.height * 0.25f)));
    }

    private boolean colisionUpRight(Vector2 vectMove)
    {
	return isCellSolid(this.x + this.getWidth() + vectMove.x, this.y + this.getHeight() + vectMove.y);
    }

    private boolean colisionUpLeft(Vector2 vectMove)
    {
	return isCellSolid(this.x + vectMove.x, this.y + this.getHeight() + vectMove.y);
    }

    private boolean colisionMiddleRight(Vector2 vectMove)
    {
	return isCellSolid(this.x + vectMove.x + this.getWidth(), this.y + vectMove.y + this.getHeight() / 2);
    }

    private boolean colisionMiddleLeft(Vector2 vectMove)
    {
	return isCellSolid(this.x + vectMove.x, this.y + vectMove.y + this.getHeight() / 2);
    }

    private boolean colisionDownLeftForLanding(Vector2 vectMove)
    {
	return colisionDown(this.x, vectMove);
    }

    private boolean colisionDownRightForLanding(Vector2 vectMove)
    {
	return colisionDown(this.x + this.width, vectMove);
    }

    private boolean colisionDown(float x, Vector2 vectMove)
    {
	boolean respuesta = false;
	if (isCellBlocked(x, this.y + vectMove.y))
	{
	    float tileY = (int) ((y + vectMove.y) / Config.getInstance().getLevelTileHeightUnits());
	    tileY = (tileY + 1) * Config.getInstance().getLevelTileHeightUnits();
	    respuesta = (this.y > tileY && this.y + vectMove.y <= tileY);
	}
	return respuesta;
    }

    private void correctRight(Vector2 vectMove)
    {
	float epsilon = 0.002f * Config.getInstance().getLevelTileWidthUnits();
	float aux = (int) ((this.x + this.getWidth() + vectMove.x) / Config.getInstance().getLevelTileWidthUnits());
	vectMove.x = (aux) * Config.getInstance().getLevelTileWidthUnits() - (this.getWidth() + epsilon + this.x);
	if (this.motionVector.y < 30)
	    this.motionVector.x = 0;

    }

    private void correctLeft(Vector2 vectMove)
    {
	float epsilon = 0.002f * Config.getInstance().getLevelTileWidthUnits();
	float aux = (int) ((this.x + vectMove.x) / Config.getInstance().getLevelTileWidthUnits());
	vectMove.x = (aux + 1) * Config.getInstance().getLevelTileWidthUnits() + epsilon - this.x;
	if (this.motionVector.y < 30)
	    this.motionVector.x = 0;

    }

    private void correctUp(Vector2 vectMove)
    {
	float epsilon = 0.001f * Config.getInstance().getLevelTileHeightUnits();
	this.motionVector.y = 0;
	int aux = (int) ((this.y + this.getHeight() + vectMove.y) / Config.getInstance().getLevelTileHeightUnits());
	vectMove.y = aux * Config.getInstance().getLevelTileHeightUnits() - (this.y + this.getHeight() + epsilon);

    }

    private void correctDown(Vector2 vectMove)
    {
	float aux = (int) ((this.y + vectMove.y) / Config.getInstance().getLevelTileHeightUnits());
	vectMove.y = (aux + 1) * Config.getInstance().getLevelTileHeightUnits() - this.y;
	if (vectMove.x == 0)
	    this.state = GameCharacter.ST_IDDLE;
	else
	{
	    this.state = GameCharacter.ST_WALKING;
	    this.lookRight = vectMove.x >= 0;
	}
	this.motionVector.y = 0;

    }

    private boolean isCellBlocked(float x, float y)
    {
	return this.pyramid.getCell(x, y) != null;
    }

    private boolean isCellSolid(float x, float y)
    {
	TiledMapTileLayer.Cell cell = this.pyramid.getCell(x, y);
	return cell != null && cell.getTile().getId() < 220;
    }

    private boolean colision(Vector2 vectMove)
    {
	if (this.state != GameCharacter.ST_WALKING && this.state != GameCharacter.ST_IDDLE)
	    this.checkLanding(vectMove);

	int r = -1;

	if (this.colisionUpRight(vectMove))
	{
	    if (this.colisionUpLeft(vectMove))
	    {
		r = Constantes.UP;
	    } else if (this.colisionMiddleRight(vectMove))
	    {
		r = Constantes.RIGHT;
	    } else
	    {
		r = this.buscarColisionPorVertice(this.x + this.width, this.y + this.height, vectMove);
		if (r == Constantes.DOWN)
		{
		    r = Constantes.RIGHT;
		    System.out.println("ABERRACION");
		}
	    }

	} else if (this.colisionUpLeft(vectMove))
	{
	    if (this.colisionMiddleLeft(vectMove))
	    {
		r = Constantes.LEFT;
	    } else
	    {
		r = this.buscarColisionPorVertice(this.x, this.y + this.height, vectMove);
		if (r == Constantes.DOWN)
		{
		    r = Constantes.LEFT;

		    System.out.println("ABERRACION");

		}
	    }
	} else if (this.isCellSolid(this.x + vectMove.x, this.y + vectMove.y)
		&& this.buscarColisionPorVertice(this.x, this.y, vectMove) == Constantes.LEFT)
	    r = Constantes.LEFT;

	else if (this.isCellSolid(this.x + vectMove.x + this.width, this.y + vectMove.y)
		&& this.buscarColisionPorVertice(this.x + this.width, this.y, vectMove) == Constantes.RIGHT)
	    r = Constantes.RIGHT;

	else if (this.colisionMiddleLeft(vectMove))
	{

	    r = Constantes.LEFT;

	} else if (this.colisionMiddleRight(vectMove))
	{

	    r = Constantes.RIGHT;

	}

	this.corrigeDirecciones(r, vectMove);

	return r != -1;
    }

    private void corrigeDirecciones(int direction, Vector2 vectMove)
    {
	switch (direction)
	{
	case Constantes.UP:
	    this.correctUp(vectMove);
	    break;

	case Constantes.LEFT:
	    this.correctLeft(vectMove);
	    break;
	case Constantes.DOWN:
	    this.correctDown(vectMove);

	    break;
	case Constantes.RIGHT:
	    this.correctRight(vectMove);
	    break;

	}

    }

    protected void checkLanding(Vector2 vectMove)
    {
	int r = -1;
	if (this.colisionDownLeftForLanding(vectMove))
	{
	    if (this.colisionDownRightForLanding(vectMove))
		this.correctDown(vectMove);
	    else
	    {
		r = this.buscarColisionPorVertice(this.x, this.y, vectMove);
	    }
	} else if (this.colisionDownRightForLanding(vectMove))
	{
	    r = this.buscarColisionPorVertice(this.x + this.width, this.y, vectMove);
	}
	this.corrigeDirecciones(r, vectMove);

    }

    private int buscarColisionPorVertice(float x, float y, Vector2 vectMove)
    {
	x += vectMove.x;
	y += vectMove.y;
	int r = -1;
	if (this.motionVector.x == 0)
	{
	    if (this.motionVector.y > 0)
		r = Constantes.UP;
	    else if (this.motionVector.y < 0)
	    {
		r = Constantes.DOWN;
	    }
	}

	else
	{

	    float m = this.motionVector.y / this.motionVector.x;
	    float b = y - x * m;
	    float valorX;
	    int tileX = (int) (x / Config.getInstance().getLevelTileWidthUnits());
	    int tileY = (int) (y / Config.getInstance().getLevelTileHeightUnits());

	    int respuestaLateral = 0;
	    if (this.motionVector.x > 0)
	    {
		valorX = tileX * Config.getInstance().getLevelTileWidthUnits();
		respuestaLateral = Constantes.RIGHT;
	    } else
	    {
		valorX = (tileX + 1) * Config.getInstance().getLevelTileWidthUnits();
		respuestaLateral = Constantes.LEFT;
	    }

	    float yBuscado = m * valorX + b;
	    float abajo = tileY * Config.getInstance().getLevelTileHeightUnits();
	    float arriba = (tileY + 1) * Config.getInstance().getLevelTileHeightUnits();
	    if (abajo <= yBuscado && yBuscado <= arriba)
		r = respuestaLateral;
	    else
	    {
		if (this.motionVector.y >= 0)
		    r = Constantes.UP;
		else
		    r = Constantes.DOWN;
	    }

	}
	return r;

    }

    public boolean isFeetColision(Rectangle another)
    {
	this.feet.x = this.x + (this.width - Config.getInstance().getCharacterFeetHeight()) / 2;
	this.feet.y = this.y;
	return LevelObject.rectangleColision(this.feet, another);
    }

    private Stair checkStairsFeetColision(ArrayList<Stair> stairs, boolean isUpping)
    {

	Iterator<Stair> it = stairs.iterator();
	Stair respuesta = null;
	Stair stair = null;
	LevelObject item = null;
	if (it.hasNext())
	    do
	    {
		stair = it.next();
		if (isUpping)
		    item = stair.getDownStair();
		else
		    item = stair.getUpStair();
	    } while (it.hasNext() && !this.isFeetColision(item));

	if (this.isFeetColision(item))
	{
	    respuesta = stair;
	}

	return respuesta;
    }

    public float getAnimationDelta()
    {
	return animationDelta;
    }

    public boolean isLookRight()
    {
	return lookRight;
    }

    private void checkOutLevel()
    {

	if (this.x < Config.getInstance().getLevelTileWidthUnits())
	{
	    this.x = Config.getInstance().getLevelTileWidthUnits();
	} else

	{
	    if (this.x > (this.pyramid.getMapWidthInTiles() - 1) * Config.getInstance().getLevelTileWidthUnits()
		    - this.width)

		this.x = (this.pyramid.getMapWidthInTiles() - 1) * Config.getInstance().getLevelTileWidthUnits()
			- this.width;
	}

    }

    @SuppressWarnings(
    { "rawtypes", "unchecked" })
    public LevelObject checkRectangleColision(ArrayList levelObjects)
    {

	Iterator<LevelObject> it = levelObjects.iterator();
	LevelObject respuesta = null;
	LevelObject item = null;
	if (it.hasNext())
	    do
	    {
		item = it.next();
	    } while (it.hasNext() && !this.isColision(item));

	if (this.isColision(item))
	{
	    respuesta = item;
	}

	return respuesta;
    }

    protected boolean checkGiratory(Vector2 v)
    {
	boolean r = false;
	LevelObject giratory = this.checkRectangleColision(this.pyramid.getGiratories());
	if (giratory != null)
	{
	    GiratoryMechanism gm = this.pyramid.getGiratoryMechanism(giratory);

	    if (this.canPassGiratoryMechanism(gm))
	    {
		this.passGiratoryMechanism(gm);

	    } else
	    {
		this.blockGiratory(gm);
		r = true;
	    }
	}
	return r;
    }

    protected boolean isLocked()
    {

	return this.isLockedRight() && this.isLockedLeft();
    }

    protected boolean isLockedLeft()
    {
	return this.pyramid.getCell(this.x - Config.getInstance().getLevelTileWidthUnits(),
		this.y + Config.getInstance().getLevelTileHeightUnits()) != null
		|| this.pyramid.getCell(this.x - Config.getInstance().getLevelTileWidthUnits(), this.y) != null;

    }

    protected boolean isLockedRight()
    {
	return this.pyramid.getCell(this.x + Config.getInstance().getLevelTileWidthUnits(),
		this.y + Config.getInstance().getLevelTileHeightUnits()) != null
		|| this.pyramid.getCell(this.x + Config.getInstance().getLevelTileWidthUnits(), this.y) != null;

    }

    protected abstract boolean canPassGiratoryMechanism(GiratoryMechanism giratoryMechanism);

    protected abstract void passGiratoryMechanism(GiratoryMechanism giratoryMechanism);

    protected void blockGiratory(GiratoryMechanism gm)
    {
	LevelObject g = gm.getLevelObject();
	float lado = g.x - this.x;

	this.motionVector.x = 0;
	if (lado < 0)
	{
	    this.x = g.x + g.width;
	} else

	{
	    this.x = g.x - this.width;
	}

    }

    protected void setState(int state)
    {
	this.state = state;
    }

    protected void resetAnimationDelta()
    {
	this.animationDelta = 0;
    }

    protected void incAnimationDelta(float delta)
    {
	this.animationDelta += delta;
    }

    protected Pyramid getPyramid()
    {
	return pyramid;
    }

}
