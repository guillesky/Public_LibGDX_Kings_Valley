package modelo.gameCharacters;

import com.badlogic.gdx.math.Vector2;

public class GameCharacterStateIddle extends GameCharacterState
{

    public GameCharacterStateIddle(GameCharacter gameCharacter)
    {
	super(gameCharacter, GameCharacter.ST_IDDLE);
	this.gameCharacter.animationDelta = 0;
    }

    @Override
    protected void move(Vector2 v, boolean b, float deltaTime)
    {
	if (v.x!=0)
	    this.gameCharacter.gameCharacterState = new GameCharacterStateWalking(this.gameCharacter);
    }

}
