package modelo.gameCharacters;

import com.badlogic.gdx.math.Vector2;

public class GameCharacterStateJumping extends GameCharacterState
{

    public GameCharacterStateJumping(GameCharacter gameCharacter)
    {
	super(gameCharacter, GameCharacter.ST_JUMPING);
	// TODO Auto-generated constructor stub
    }

    @Override
    protected void move(Vector2 v, boolean b, float deltaTime)
    {
	// TODO Auto-generated method stub

    }

}
