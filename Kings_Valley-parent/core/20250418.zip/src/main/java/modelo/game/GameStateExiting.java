package modelo.game;

public class GameStateExiting extends GameState
{

    @Override
    public void updateframe(float deltaTime)
    {
	// TODO Auto-generated method stub

    }

}
