package engine.level;

/**
 * @author Guillermo Lazzurri
 * 
 *         Representa un mecanismo en el nivel, es decir, un objeto que realiza
 *         alguna accion que requiere tiempo para tarminar
 */
public abstract class Mechanism
{
	protected float time = 0;
	protected float timeToEnd;
	protected boolean active = true;

	/**
	 * Llamado para actualizar el estado
	 * 
	 * @param deltaTime indica el tiempo tranucurrido dede la ultima llamada
	 */
	public abstract void update(float deltaTime);

	/**
	 * Constructor de clase
	 * 
	 * @param timeToEnd indica el tiempo necesario para terminar
	 */
	public Mechanism(float timeToEnd)
	{

		this.timeToEnd = timeToEnd;
	}

	/**
	 * @return true si esta activo, false en caso contrario
	 */
	public boolean isActive()
	{
		return active;
	}

	/**
	 * @return el tiempo que lleva activo
	 */
	public float getTime()
	{
		return time;
	}

	/**
	 * incrementa el tiempo que esta activo el mecanismo
	 * 
	 * @param delta tiempo de incremento
	 */
	protected void incTime(float delta)
	{
		this.time += delta;
	}

	/**
	 * Pone en cero el tiempo
	 */
	protected void resetTime()
	{
		this.time = 0;
	}

	/**
	 * @return el tiempo que tarda en terminar el ciclo
	 */
	public float getTimeToEnd()
	{
		return timeToEnd;
	}

}
