package io.github.some_example_name;

import com.badlogic.gdx.ApplicationListener;

import modelo.IGrafica;

public interface IMyApplicationnListener extends IGrafica, ApplicationListener
{

}
