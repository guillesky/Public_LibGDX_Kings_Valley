package modelo;

public interface IGraphicRenderer
{
void updateElement(Object element);

}
