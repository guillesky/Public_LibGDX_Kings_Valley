<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tiles" tilewidth="10" tileheight="10" tilecount="260" columns="20">
 <image source="../pics/tiles2.png" width="200" height="130"/>
</tileset>
