<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tiles" tilewidth="10" tileheight="10" tilecount="144" columns="18">
 <image source="../pics/tiles4.png" width="180" height="80"/>
</tileset>
